package com.zombie_cute.mc.bakingdelight.mixin;

import net.minecraft.recipe.BrewingRecipeRegistry;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BrewingRecipeRegistry.class)
public class BrewingMixin {

}